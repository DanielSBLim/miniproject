package db;

public class MemberDTO {
	private String id;
	private String pw;
	private String nickname;
	
	public MemberDTO(String id, String pw, String nickname) {
		this.id = id;
		this.pw = pw;
		this.nickname = nickname;
	}
	
}
