package main;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JPanel;

import membershipLayout.*;

public class MembershipProject extends JFrame {

	JPanel[] emtpy = { new JPanel(), new JPanel(), new JPanel(), new JPanel() };
	LoginID loginID = new LoginID();
	LoginPW loginPW = new LoginPW();
	CreativeMember creativeMember = new CreativeMember();
	UpDateMember upDateMember = new UpDateMember();
	DelMember delMember = new DelMember();
	MainMember mainMember = new MainMember();

	MembershipProject() {
		super("membership");
		initViews();
		setEvent();
		start();
		initWindowSetting();
	}

	void initViews() {

		emtpy[0].setBackground(Color.white);
		emtpy[0].setPreferredSize(new Dimension(63, 700));
		emtpy[1].setBackground(Color.white);
		emtpy[1].setPreferredSize(new Dimension(49, 700));
		emtpy[2].setBackground(Color.white);
		emtpy[3].setBackground(Color.white);
		emtpy[2].setPreferredSize(new Dimension(500, 51));
		add(emtpy[0], BorderLayout.WEST);
		add(emtpy[1], BorderLayout.EAST);
		add(emtpy[2], BorderLayout.SOUTH);
		add(emtpy[3], BorderLayout.NORTH);
	}

	void initWindowSetting() {
		setSize(500, 700);
		setVisible(true);
		setResizable(false);
	}

	private void setEvent() {
		loginID.setUserActionListener(new LoginID.UserActionListener() {

			@Override
			public void onClickNext() {

			}

			@Override
			public void onClickCreat() {

			}
		});
		loginPW.setUserActionListener(new LoginPW.UserActionListener() {

			@Override
			public void onClickNext() {

			}

			@Override
			public void onClickCreat() {

			}
		});
		upDateMember.setUserActionListener(new UpDateMember.UserActionListener() {

			@Override
			public void onClickRemove() {

			}

			@Override
			public void onClickNext() {
			}
		});

		creativeMember.setUserActionListener(new CreativeMember.UserActionListener() {

			@Override
			public void onClickNext() {
			}

			@Override
			public void onClickNew() {

			}
		});

		mainMember.setUserActionListener(new MainMember.UserActionListener() {
			@Override
			public void onClickStart() {

			}

			@Override
			public void onClickUpdate() {
			}
		});

	}

	void start() {
		add(loginID, BorderLayout.CENTER);

	}
}
