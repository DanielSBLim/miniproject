package myValue;

import java.awt.Color;

public class MyColor {

	public static final Color lightBlue = new Color(26, 115, 232);
}
