package db;

import java.util.ArrayList;
import java.util.List;

public class MemberTable {

	private List<MemberDTO> list = new ArrayList<MemberDTO>();
	
	public MemberTable(){
		list.add(new MemberDTO("qq1", "qpqp1010", "Charles"));
		list.add(new MemberDTO("qq2", "qpqp1010", "Daniel"));
		list.add(new MemberDTO("qq3", "qpqp1010", "Sin"));
	}
	
	public boolean isContainId(String id) {
		for (MemberDTO memberDTO : list) {
			if(memberDTO.getId().equals(id)) {
				return true;
			}
		}
		return false;
	}
	
	public MemberDTO getMemberInfo(String id, String pw) {
		for (MemberDTO memberDTO : list) {
			if(memberDTO.getId().equals(id) && memberDTO.getPw().equals(pw)) {
				return memberDTO;
			}
		}
		return null;
	}
	
	public boolean updateInfo(String id, String pw, String nick) {
		for (MemberDTO memberDTO : list) {
			if(memberDTO.getId().equals(id) && memberDTO.getPw().equals(pw)) {
				memberDTO.setNickname(nick);
				return true;
			}
		}
		return false;
	}
	
	public boolean signout(String id, String pw) {
		for (MemberDTO memberDTO : list) {
			if(memberDTO.getId().equals(id) && memberDTO.getPw().equals(pw)) {
				list.remove(memberDTO);
				return true;
			}
		}
		return false;
	}
	
	public boolean createId(String id, String pw, String nick) {
		if(!id.isEmpty() && !isContainId(id)) {
			list.add(new MemberDTO(id,pw,nick));
			return true;
		}
		return false;
	}
}
