package membershipLayout;

import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class DelMember extends PanelBase {
	
	private JLabel DelImage = new JLabel("", JLabel.CENTER);
	
	public DelMember() {
		super(new GridLayout(1, 1));
		initViews();
	}
	
	private void initViews(){
		setBackground(Color.white);
		DelImage.setIcon(new ImageIcon("./menber/delMember.jpg"));
		add(DelImage);
	}
	
	@Override
	public void clear() {
		// TODO Auto-generated method stub
	}
}
