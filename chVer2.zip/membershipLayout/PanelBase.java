package membershipLayout;

import java.awt.LayoutManager;

import javax.swing.JPanel;

public abstract class PanelBase extends JPanel{
	
	public PanelBase(LayoutManager manager) {
		super(manager);
	}
	
	public abstract void clear();
}
