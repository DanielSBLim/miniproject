package membershipLogic;

import db.MemberDTO;

public interface MembershipContract {
	interface View{
		//화면전환 메소드
		void moveToMemberCreateView();
		void moveToIdView();
		void moveToPwView();
		void moveToMemberModifyView();
		void moveToSignoutView();
		void moveToMain(MemberDTO sessionInfo);
		
		//에러 케이스
		void showNotFoundId();
		void showInvalidPw();
		void showFailedNicknameUpdate();
		void showDuplicatedId();
	}
	
	interface Presenter{
		void checkedId(String id);
		void checkedPw(String pw);
		void updateInfo(String pw, String nickName);
		void createId(String id, String pw, String nickName);
		void removeMember();
	}
}
