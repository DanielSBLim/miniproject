package membershipLogic;

import db.MemberDTO;
import db.MemberTable;

public class MembershipModel {
	private MemberTable memberTable = new MemberTable(); // 전체유저정보
	private MemberDTO sessionInfo = new MemberDTO(); // 내정보
	
	public void setNickname(String nickName) {
		sessionInfo.setNickname(nickName);
	}
	
	public boolean isContainId(String id) {
		if(memberTable.isContainId(id)) {
			sessionInfo.setId(id);
			return true;
		}
		return false;
	}
	
	public boolean isValidation(String pw) {
		MemberDTO sessionInfo = memberTable.getMemberInfo(this.sessionInfo.getId(), pw);
		if(sessionInfo != null) {
			this.sessionInfo = sessionInfo;
			return true;
		}
		return false;
	}
	
	public boolean updateInfo(String pw, String nickName) {
		if(memberTable.updateInfo(sessionInfo.getId(), pw, nickName)) {
			setNickname(nickName);
			return true;
		}
		return false;
	}
	
	public boolean createId(String id, String pw, String nickName) {
		return memberTable.createId(id, pw, nickName);
	}
	
	public boolean removeMember() {
		String id = sessionInfo.getId();
		String pw = sessionInfo.getPw();
		if(id != null && !id.isEmpty() && pw != null && !pw.isEmpty()) {
			return memberTable.signout(id, pw);
		}
		return false;
	}
	
	public MemberDTO getSessionInfo() {
		return sessionInfo;
	}
}
