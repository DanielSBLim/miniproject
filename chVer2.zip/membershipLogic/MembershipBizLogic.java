package membershipLogic;

public class MembershipBizLogic implements MembershipContract.Presenter{

	private MembershipContract.View view;
	private MembershipModel membershipModel = new MembershipModel();
	
	public MembershipBizLogic(MembershipContract.View view) {
		this.view = view;
	}

	@Override
	public void checkedId(String id) {
		if(membershipModel.isContainId(id)) {
			view.moveToPwView();
		}else {
			view.showNotFoundId();
		}
	}

	@Override
	public void checkedPw(String pw) {
		if(membershipModel.isValidation(pw)) {
			view.moveToMain(membershipModel.getSessionInfo());
		}else {
			view.showInvalidPw();
		}
	}

	@Override
	public void updateInfo(String pw, String nickName) {
		if(membershipModel.updateInfo(pw, nickName)) {
			view.moveToMain(membershipModel.getSessionInfo());
		}else {
			view.showFailedNicknameUpdate();
		}
	}
	
	@Override
	public void createId(String id, String pw, String nickName) {
		if(membershipModel.createId(id, pw, nickName)) {
			view.moveToIdView();
		}else {
			view.showDuplicatedId();
		}
	}
	
	@Override
	public void removeMember() {
		if(membershipModel.removeMember()) {
			view.moveToSignoutView();
		}else {
			view.showNotFoundId();
		}
	}
}
