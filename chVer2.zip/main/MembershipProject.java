package main;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JPanel;

import db.MemberDTO;
import membershipLayout.CreativeMember;
import membershipLayout.DelMember;
import membershipLayout.LoginID;
import membershipLayout.LoginPW;
import membershipLayout.MainMember;
import membershipLayout.PanelBase;
import membershipLayout.UpDateMember;
import membershipLogic.MembershipBizLogic;
import membershipLogic.MembershipContract;

public class MembershipProject extends JFrame implements MembershipContract.View{

	private JPanel[] emtpy = { new JPanel(), new JPanel(), new JPanel(), new JPanel() };
	private LoginID loginID = new LoginID();
	private LoginPW loginPW = new LoginPW();
	private	CreativeMember creativeMember = new CreativeMember();
	private UpDateMember upDateMember = new UpDateMember();
	private DelMember delMember = new DelMember();
	private MainMember mainMember = new MainMember();
	private PanelBase currentView;
	
	private MembershipBizLogic bizLogic = new MembershipBizLogic(this); //비즈니스로직 클래스

	public MembershipProject() {
		super("membership");
		initViews();
		setEvent();
		startPanel();
		initWindowSetting();
	}
	
	private void startPanel() {
		add(loginID, BorderLayout.CENTER);
		currentView = loginID;
	}

	private void initViews() {
		emtpy[0].setBackground(Color.white);
		emtpy[0].setPreferredSize(new Dimension(63, 700));
		emtpy[1].setBackground(Color.white);
		emtpy[1].setPreferredSize(new Dimension(49, 700));
		emtpy[2].setBackground(Color.white);
		emtpy[3].setBackground(Color.white);
		emtpy[2].setPreferredSize(new Dimension(500, 51));
		add(emtpy[0], BorderLayout.WEST);
		add(emtpy[1], BorderLayout.EAST);
		add(emtpy[2], BorderLayout.SOUTH);
		add(emtpy[3], BorderLayout.NORTH);
	}

	private void initWindowSetting() {
		setSize(500, 700);
		setVisible(true);
		setResizable(false);
	}

	private void setEvent() {
		loginID.setUserActionListener(new LoginID.UserActionListener() {

			@Override
			public void onClickNext(String id) {
				bizLogic.checkedId(id);
			}

			@Override
			public void onClickCreat() {
				moveToMemberCreateView();
			}
		});
		loginPW.setUserActionListener(new LoginPW.UserActionListener() {

			@Override
			public void onClickNext(String pw) {
				System.out.println("다음 출력");
				bizLogic.checkedPw(pw);
			}

			@Override
			public void onClickCreat() {
				moveToMemberCreateView();
			}
		});
		upDateMember.setUserActionListener(new UpDateMember.UserActionListener() {

			@Override
			public void onClickRemove() {
				bizLogic.removeMember();
			}

			@Override
			public void onClickNext(String pw, String nick) {
				bizLogic.updateInfo(pw, nick);
			}
		});

		creativeMember.setUserActionListener(new CreativeMember.UserActionListener() {
			@Override
			public void onClickCreateId(String id, String pw, String nickname) {
				bizLogic.createId(id, pw, nickname);
			}
		});

		mainMember.setUserActionListener(new MainMember.UserActionListener() {
			@Override
			public void onClickStart() {
				new AlgorithmProject();
				setVisible(false);
			}

			@Override
			public void onClickUpdate() {
				moveToMemberModifyView();
			}
		});
	}
	
	@Override
	public void showNotFoundId() {
		// TODO id가 없습니다.
		System.out.println("id가 없습니다.");
		loginID.errNotFoundId();
	}

	@Override
	public void showInvalidPw() {
		// TODO 비밀번호가 틀렸습니다.
		System.out.println("비밀번호가 틀렸습니다.");
		loginPW.errVis();
	}
	
	@Override
	public void showFailedNicknameUpdate() {
		// TODO 닉네임 업데이트 실패했습니다.
		System.out.println("닉네임 업데이트 실패했습니다.");
		upDateMember.errVisPW();
		upDateMember.errVisNick();
	}
	
	@Override
	public void showDuplicatedId() {
		// TODO 중복된 아이디입니다.
		System.out.println("중복된 아이디입니다.");
		creativeMember.errVisIdDupulicated();
	}

	@Override
	public void moveToMemberCreateView() {
		changeLayout(creativeMember);
	}

	@Override
	public void moveToIdView() {
		changeLayout(loginID);
	}

	@Override
	public void moveToPwView() {
		changeLayout(loginPW);
	}

	@Override
	public void moveToMemberModifyView() {
		changeLayout(upDateMember);
	}

	@Override
	public void moveToSignoutView() {
		changeLayout(delMember);
	}
	
	@Override
	public void moveToMain(MemberDTO sessionInfo) {
		mainMember.setNickname(sessionInfo);
		changeLayout(mainMember);
	}
	
	private void changeLayout(PanelBase layout) {
		if(currentView != null) {
			currentView.clear();
			remove(currentView);
		}
		add(layout);
		revalidate();
		repaint();
		currentView = layout;
	}
}
